$(document).ready(function () {
    $("#search").click(function () {
        $w = $("#word").val();
        $.ajax("http://localhost:3000/search", {
            type: 'POST',
            data: { word: $w }
        })
            .done(successFunction);
    });
    function successFunction(data) {

    }
});