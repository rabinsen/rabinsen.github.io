var mysql = require('mysql');
var searchWord = function(connection, word) {
    connection.connect(function (err) {
        if (err) {
            throw err;
        }
        connection.query("SELECT * FROM entries WHERE word= " + mysql.escape(word), (err, result) => {
            if (err) throw err;
            console.log(result);
            return result;
        });
    });
}

exports.searchWord = searchWord;