data = function(){
    return [
        {"question" : [3, 1, 4, 1, 5], "ans" : 9},
        {"question" : [1, 1, 2, 3, 5], "ans" : 8},
        {"question" : [1, 4, 9, 16, 25], "ans" : 36},
        {"question" : [2, 3, 5, 7, 11], "ans" : 13},
        {"question" : [1, 2, 4, 8, 16], "ans" : 32}
    ];
}
exports.data = data;